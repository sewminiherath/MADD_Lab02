package com.example.lab02

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

class BillCalculatorActivity : AppCompatActivity() {

    private lateinit var txtUnits: EditText
    private lateinit var btnCalculate: Button
    private lateinit var lblResult: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bill_calculator)

        txtUnits = findViewById(R.id.txtUnits)
        btnCalculate = findViewById(R.id.btnCalculate)
        lblResult = findViewById(R.id.lblResult)

        btnCalculate.setOnClickListener {
            val units = txtUnits.text.toString().trim().toIntOrNull()
            if (units == null || units < 0) {
                lblResult.text = "Electricity Bill: Please enter a valid non-negative number."
                return@setOnClickListener
            }
            val total = calculateBill(units)
            val formatted = "LKR " + String.format(Locale.US, "%,.2f", total)
            lblResult.text = "Electricity Bill: $formatted"
        }
    }

    // Formula required by the lab:
    // Fixed 150 + (Units × 29) + 15% VAT. :contentReference[oaicite:5]{index=5}
    private fun calculateBill(units: Int): Double {
        val fixed = 150.0
        val unitCost = 29.0
        val subTotal = fixed + units * unitCost
        val vat = subTotal * 0.15
        return subTotal + vat
    }
}
